<!DOCTYPE html>
<html>
<head>
	<title>SPLI - Contact</title>
</head>
        <link rel="stylesheet" href="css/main.css" type="text/css" />
    	<link rel="stylesheet" href="css/contact.css" type="text/css" />
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="icon" href="http://www.spli.ph/Lobo.ico" type="image/x-icon" />
        <!-- This is needed for IE -->
        <link rel="shortcut icon" href="http://www.spli.ph/Lobo.ico" type="image/ico" />
<body>
    <div class="wrap">
        <div class="head sticky">
            <div class="col-2 logo">
                <img src="img/menu-button.png">
                <h2>Susumi Philippine Logistics, Inc.</h2>
            </div>
            <div class="col-4 navs">
                <ul>
                    <li class="here"><a href="index.php" >Home</a></li>
                    <li class="here"><a href="services.php" >Services</a></li>
                    <li class="here"><a href="facilities.php">Facilities</a></li>
                    <li class="here"><a href="about.php">About</a></li>
                    <li class="inhere"><a href="contact.php">Contact Us</a></li>
                </ul>
            </div>
        </div>
        <div class="cs-service">
            <div class="col-3 days-open">
                <br>
                <h3>Available Hours</h3>
                <p>Our office and warehouse is available from Monday to Friday.<br><br>
                Every <strong>Monday</strong> from <strong>8:30AM to 5:30PM</strong>,<br> <strong>Tuesday</strong> to <strong>Friday</strong> from <strong>8:00AM</strong> to <strong>6:00PM</strong> and <strong>Saturday</strong> if the client/s requested to or with special instruction.</p>
                <br>
                <h3>Contact us through</h3>
                <p>
                 <strong>Email:</strong>&nbsp;&nbsp;&nbsp;&nbsp;
                    inquire@spli.ph<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    customer_service@spli.ph<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    salesandmarketing@spli.ph<br><br>
                    <strong>Tel. No. :</strong>&nbsp;&nbsp; +63 043 405 7013<br>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; +63 043 405 7020 - 22</p>
                <br><br>
                <em>*Formerly known as SGL Philippines E-Zone Services, Inc.</em>
            </div>
            <div class="col-3 mailing">
                <form>
                    <p>Name:</p>
                    <input type="text" name="fullname">
                    <p>Company Name:</p>
                    <input type="text" name="companyname">
                    <p>Contact Number:</p>
                    <input type="text" name="contactnumber">
                    <p>Message:</p>
                    <input class="message" type="text" name="message">
                    <br>
                    <input type="submit" name="send">
                </form>
            </div>
        </div>
        <br>
        <div class="col-6 mapps">
            <h2>Locate Us</h2>
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3868.912051005346!2d121.1299673148348!3d14.141267990096322!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x33bd64513dcf2c95%3A0xfbca355e6015a43b!2sSUSUMI+PHILIPPINE+LOGISTICS%2C+INC.!5e0!3m2!1sen!2sph!4v1517196614131" allowfullscreen></iframe>
        </div>
        <div class="footer">
            <div class="col-2 footlink ulast">
                <h3>Services</h3>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="services.php" >Services</a></li>
                    <li><a href="facilities.php">Facilities</a></li>
                    <li><a href="about.php">About</a></li>
                    <li><a href="contact.php">Contact Us</a></li>
                </ul>
                <img src="img/spliLogo.jpg" alt="SPLI Logo">
                 <p>Susumi Philippine Logistics, Inc.</p>
                 <p>SPLI - All Rights Reserved 2018&reg;</p>
            </div>
            <div class="col-2 footlink flast">
                <h3>We are social</h3>
                <a href="https://www.google.com/maps?ll=14.141268,121.132156&z=16&t=m&hl=en-US&gl=PH&mapclient=embed&cid=18143372728270693435" title="Find in Google Map" target="_blank" ><img src="img/001-google.png" alt="SPLI Logo"></a>
                <a href="#"><img src="img/002-skype.png" alt="SPLI Logo"></a>
                <a href="https://plus.google.com/share?url=" title="Share on Google+" target="_blank"><img src="img/003-google-plus.png" alt="SPLI Logo"></a>
                <a  href="https://www.facebook.com/sharer/sharer.php?u=" title="Share on Facebook" target="_blank"><img src="img/004-facebook.png" alt="SPLI Logo"></a>
                <h5>Tel. No.: +63 43 405 7020</h5>
                <h5>Email : inquire@spli.ph</h5>
                <h5>Former SGL Philippines E-Zone Services Inc.</h5>
            </div>
            <div class="col-2 footlink flast">
                <h3>Need Help?</h3>
                <ul>
                    <li><a href="services.php">International Multi-Through Transportation</a></li>
                    <li><a href="services.php" >Ocean &amp; AirCargo Business </a></li>
                    <li><a href="services.php">Currier Service</a></li>
                    <li><a href="services.php">Project Cargo Business</a></li>
                    <li><a href="services.php">Storage and Warehousing</a></li>
                    <li><a href="services.php">Trucking Services</a></li>
                </ul>
            </div>
        </div>
    </div>
    <p class="coder">Website Developed by: N. Valenzuela 2018 - valenzuela.nomer@yahoo.com</p>
    <script src="js/jquery3-3-1.js"></script>
    <script src="js/accord.js"></script>
    <script src="js/js_slide.js"></script> 
</body>
</html>