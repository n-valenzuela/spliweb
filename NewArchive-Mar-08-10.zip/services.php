<!DOCTYPE html>
<html>
<head>
	<title>SPLI - Services</title>
	<link rel="stylesheet" href="css/main.css" type="text/css" />
    	<link rel="stylesheet" href="css/services.css" type="text/css" />
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="icon" href="http://www.spli.ph/Lobo.ico" type="image/x-icon" />
		<!-- This is needed for IE -->
		<link rel="shortcut icon" href="http://www.spli.ph/Lobo.ico" type="image/ico" />
</head>
<body>
	<div class="wrap">
        <div class="head sticky">
           <div class="col-2 logo">
                <img src="img/menu-button.png">
                <h2>Susumi Philippine Logistics, Inc.</h2>
            </div>
            <div class="col-4 navs">
                <ul>
                    <li class="here"><a href="index.php" >Home</a></li>
                    <li class="inhere"><a href="services.php">Services</a></li>
                    <li class="here"><a href="facilities.php">Facilities</a></li>
                    <li class="here"><a href="about.php">About</a></li>
                    <li class="here"><a href="contact.php">Contact Us</a></li>
                </ul>
            </div>
        </div>
        <div class="services">
        	<h2>SPLI - Services We Offer</h2>
        	<p>We offer services for companies with import and export needs and companies that are Philippine Economic Zone Authority (PEZA) Certified. We can transfer all kinds of item, from your precious documents to raw materials and finished products from zone to another locally or internationally. We can store all types of cargoes whether in a pallet, boxes or big rolls and we can also provide temperature contolled room storage. Select one of the categories we can work on below.</p>
        	<div class="firstServices">
	        	<div class="col-3 air">
		        	<div class="accord-container">
		        		<div class="accordion"><p>Air - Imports</p></div>
		        		<div class="panel">
		        			<p>We can help you manage your cargoes from Asia, Europe and US to the Philippines. Connect your business branch by sending shipments in order to continue your production.</p>
			        	</div>
			        	<div class="accordion"><p>Air - Exports</p></div>
		        		<div class="panel">
		        			<p>Affiliated with local and international forwarders like UPS, FedEx and Air21 to make a partnership that ensures fast, reliable, and economical freight services.</p>
			        	</div>
			        	<div class="accordion"><p>Business Cargo Project</p></div>
		        		<div class="panel">
		        			<p>We can provide services for disassembly, Packing, Crating of cargo, marine and overland transportation on to factory site installation of equipment and machinery</p>
			        	</div>
		        	</div>	        	
	        	</div>
	        	<div class="col-3 ocean">
		        	<div class="accord-container">
		        		<div class="accordion"><p>Ocean - Imports</p></div>
		        		<div class="panel">
		        			<p>Manage your import shipments through our import ocean services. Our outsource agents will help you keep updated about your cargoes.</p>
			        	</div>
			        	<div class="accordion"><p>Ocean - Exports</p></div>
		        		<div class="panel">
		        			<p>Manage your export shipments through our export ocean services. We have outsource agents that will help you keep updated about your cargoes. We can help you send cargoes by biggest Ocean ports from Batangas and from Manila.</p>
			        	</div>
			        	<div class="accordion"><p>Warehousing and Transport</p></div>
		        		<div class="panel">
		        			<p>SPLI is located in one of the largest industrial park in the Philippines - FPIP and even near other industrial park in Laguna, Cavite, and Batangas. We can help you store your excess cargoes and transfer them whenever you need through our warehousing and trucking services</p>
			        	</div>
		        	</div>	        	
	        	</div>
	        </div>
	    </div>
	     <br>
	     <br>
	     <div class="service-cover">
	     	<div class="col-2 tab">
	     		<ul>
	     			<li class="act"><a href="#tab1">Import Service</a></li>
	     			<li><a href="#tab2">Export Service</a></li>
	     			<li><a href="#tab3">Trucking Service</a></li>
	     			<li><a href="#tab4">Warehousing Service</a></li>
	     			<li><a href="#tab5">Company Permits</a></li>
	     		</ul>
	     	</div>
	     	<div class="service-description">
	     		<div id="tab1" class="col-4 tab-con act">
	     			<h4>Import Services</h4>
	     			<p>May includes the following:</p>
	     			<ul>
	     				<li>Import Clearance</li>
	     				<li>General / Dagerous Goods Handling</li>
	     				<li>Brokerage</li>
	     				<li>Document Handling</li>
	     				<li>Express Clearance</li>
	     				<li>D&amp;T Advancecment</li>
	     				<li>Lodgement</li>
	     				<li>Port Conduction</li>
	     				<li>Breakbulk</li>
	     				<li>Customs and related Documentation</li>
	     			</ul>
	     		</div>
	     		<div id="tab2" class="col-4 tab-con">
	     			<h4>Export Services</h4>
	     			<p>May include the following:</p>
	     			<ul>
	     	 			<li>Air Freight</li>
	     	 			<li>Ocean Freight</li>
	     	 			<li>Export Clearance</li>
	     	 			<li>Documentation</li>
	     	 			<li>Handling</li>
	     	 			<li>Trucking Pick-Up</li>
	     	 			<li>OLRS</li>
	     	 			<li>DFS</li>
	     	 			<li>Customs and related Documentation</li>
	     	 			<li>Arastre/Wharfage</li>
	     			</ul>
	     		</div>
	     		<div id="tab3" class="col-4 tab-con">
	     			<h4>Trucking Services</h4>
	     			<p>May include the following:</p>
	     			<ul>
	     				<li>Trucking</li>
	     				<li>4W, 6W, 10W</li>
	     				<li>Crating/Packing</li>
	     				<li>Urgent Delivery</li>
	     				<li>ODA</li>
	     				<li>OPA</li>
	     				<li>Documents Return</li>
	     			</ul>
	     		</div>
	     		<div id="tab4" class="col-4 tab-con">
	     			<h4>Warehousing Services</h4>
	     			<p>Includes the following:</p>
	     			<ul>
	     				<li>Regular Storage</li>
	     				<li>Cool Room Storage</li>
	     				<li>Warehouse IN and OUT</li>
	     				<li>PEZA Farm IN and OUT</li>
	     				<li>Pallet Rental and Repalletizing</li>
	     				<li>License Requirement</li>
	     				<li>Inventory Management</li>
	     			</ul>
	     		</div>
	     		<div id="tab5" class="col-4 tab-con">
	     			<h4>Permits we have</h4>
	     			<p>Includes the following:</p>
	     			<ul>
	     				<li>PDEA</li>
	     				<li>DENR</li>
	     				<li>PEZA</li>
	     				<li>PNP</li>
	     				<li>DDB</li>
	     			</ul>
	     		</div>
	     	</div>
	     </div>
	     <br>
         <div class="footer">
            <div class="col-2 footlink ulast">
            	<h3>Services</h3>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="services.php" >Services</a></li>
                    <li><a href="facilities.php">Facilities</a></li>
                    <li><a href="about.php">About</a></li>
                    <li><a href="contact.php">Contact Us</a></li>
                </ul>
                <img src="img/spliLogo.jpg" alt="SPLI Logo">
                 <p>Susumi Philippine Logistics, Inc.</p>
                 <p>SPLI - All Rights Reserved 2018&reg;</p>
            </div>
            <div class="col-2 footlink flast">
                <h3>We are social</h3>
                <a href="https://www.google.com/maps?ll=14.141268,121.132156&z=16&t=m&hl=en-US&gl=PH&mapclient=embed&cid=18143372728270693435" title="Find in Google Map" target="_blank" ><img src="img/001-google.png" alt="SPLI Logo"></a>
                <a href="#"><img src="img/002-skype.png" alt="SPLI Logo"></a>
                <a href="https://plus.google.com/share?url=" title="Share on Google+" target="_blank"><img src="img/003-google-plus.png" alt="SPLI Logo"></a>
                <a  href="https://www.facebook.com/sharer/sharer.php?u=" title="Share on Facebook" target="_blank"><img src="img/004-facebook.png" alt="SPLI Logo"></a>
                <h5>Tel. No.: +63 43 405 7020</h5>
                <h5>Email : inquire@spli.ph</h5>
                <h5>Former SGL Philippines E-Zone Services Inc.</h5>
            </div>
            <div class="col-2 footlink flast">
                <h3>Need Help?</h3>
                <ul>
                    <li><a href="services.php">International Multi-Through Transportation</a></li>
                    <li><a href="services.php" >Ocean &amp; AirCargo Business </a></li>
                    <li><a href="services.php">Currier Service</a></li>
                    <li><a href="services.php">Project Cargo Business</a></li>
                    <li><a href="services.php">Storage and Warehousing</a></li>
                    <li><a href="services.php">Trucking Services</a></li>
                </ul>
            </div>
        </div>
    </div>
    <p class="coder">Website Developed by: N. Valenzuela 2018 - valenzuela.nomer@yahoo.com</p>

    <script src="js/jquery3-3-1.js"></script>
	<script src="js/accord.js"></script>
	<script src="js/js_slide.js"></script>  
</body>
</html>