<!DOCTYPE html>
<html>
<head>
	<title>SPLI - About</title>
</head>
        <link rel="stylesheet" href="css/main.css" type="text/css" />
    	<link rel="stylesheet" href="css/about.css" type="text/css" />
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="icon" href="http://www.spli.ph/Lobo.ico" type="image/x-icon" />
        <!-- This is needed for IE -->
        <link rel="shortcut icon" href="http://www.spli.ph/Lobo.ico" type="image/ico" />
<body>
	    <div class="wrap">
        <div class="head sticky">
            <div class="col-2 logo">
                <img src="img/menu-button.png">
                <h2>Susumi Philippine Logistics, Inc.</h2>
            </div>
            <div class="col-4 navs">
                <ul>
                    <li class="here"><a href="index.php" >Home</a></li>
                    <li class="here"><a href="services.php" >Services</a></li>
                    <li class="here"><a href="facilities.php">Facilities</a></li>
                    <li class="inhere"><a href="about.php">About</a></li>
                    <li class="here"><a href="contact.php">Contact Us</a></li>
                </ul>
            </div>
        </div>
        <div class="history">
            <div class="col-3 history-art">
                <h3>SPLI History</h3>
                <p><strong>August 31, 2005</strong><br>
                SGL Philippines E-Zone Services, Inc. was established to be one of the best warehousing, logistics and freight forwarding company fully committed to meet customer demands as well as statutory and regulatory requirements.
                <br>
                <br>
                <strong>October 26, 2005</strong><br>
                The Company is registered with PEZA under Republic Acts (RA) No. 7916, as an Economic Logistics Service Enterprise at the First Philippine Industrial Park (FPIP) - Special Economic Zone.
                <br>
                <br>
                <strong>October 28, 2008</strong><br>
                SGL Philippines E-Zone Services, Inc. and Sumisho Global Logistics Phils., Inc. merged. The Company was registered with Securities and Exchange Commission last August 31, 2005 and started its commercial operation last December 01, 2005.
                <br>
                <br>
                <strong>December 17, 2008</strong><br>
                Company merged with its sister company, Sumisho Global Logistics Phils. Inc. Merged operation started on January 01, 2009.
                <br>
                <br>
                <strong>January 05, 2015</strong><br>
                The company successfully had its new name approved by the Security and Exchange Commission as SUSUMI PHILIPPINE LOGISTICS, INC. </p>
            </div>
             <div class="col-3 missionvision">
                <h3>Our Mission</h3>
                <p>“To produce superior financial returns for shareowners by providing high value-added supply chain, transportation, business and related information and logistical services. Customer requirements will be met in the highest quality manner appropriate to each market segment served. SPLI will strive to develop mutually rewarding relationships with its employees, partners and suppliers. Safety will be the first consideration in all operations. Corporate activities will be conducted to the highest ethical and professional standards.” </p>
                <h3>Our Vision</h3>
                <p>“Creating, selling and delivering logistical solutions globally in such a way that our customers’ businesses always run better when partnering with us.”</p>
            </div>
        </div>
        <div class="col-6 news">
            <h1>SPLI News</h1>
             <div class="accord-container">
                <div class="accordion"><p>New Fork Lift Vehicle Acquired by SPLI</p><em> - Feb. 21, 2018</em></div>
                    <div class="panel">
                        <img src="img/b1.jpg">
                        <p>SPLI continues to improve their services by replacing old Forklift and Reach Truck from NICHIYU. 2 units were acquired as brand new vehicles from TOYOTA which will help improved warehouse process and safety. These 2 vehicle will be used in SPLI's main warehouse where the office is located as well.</p>
                    </div>
                    <div class="accordion"><p>Maximizing Building M's Storage</p><em> - Jan. 16, 2018</em></div>
                    <div class="panel">
                        <img src="img/B10.jpg">
                        <p>To continue serving our Clients, SPLI is putting on 10 stalls of rack storage in its second warehouse in First Philippine Industrial Park. Building M being SPLI's largest warehouse will now be maximized and serve more clients.</p>
                    </div>
                    <div class="accordion"><p>SPLI 2017 Summer Team Building</p><em> - June. 26, 2017</em></div>
                    <div class="panel">
                        <img src="img/art02.jpg">
                        <p>After being certified by ISO 9001 (QMS) version 2015, SPLI rejoice its yearly summer activity by engaging employees in a fun and creative Team Building. Held in The Forest Club Eco Resort, Laguna.</p>
                    </div>
                    <div class="accordion"><p>SPLI : Certified by ISO 9001:2015</p><em> - Aug. 23, 2017</em></div>
                    <div class="panel">
                        <img src="img/art01.jpg">
                        <p>In adaptation to the new version of ISO 9001 QMS, passes the external party Audit of ISO 9001:2015. SPLI continues to improve its services by having a define procedure guided by and certified under clauses defined by many standard organization. </p>
                    </div>
            </div>              
        </div>
        <!--div class="col-6 faqs">
            <h1>Frequently Asked Question/s - FAQ</h1>
             <div class="accord-container">
                <div class="accordion accord-faq"><p>Do you provide distribution service from local to local industry?</p></div>
                    <div class="panel faq-panel">
                        <p>Yes we do. Aside from overseas' import and export distribution we can also provide distribution service locally and/but with limited zone to zone or to PEZA certified companies only. For none PEZA Company with nationwide local distribution, we can refer your needs to our related company Air21.</p>
                    </div>
                    <div class="accordion accord-faq"><p>What  requirements do you need for us to be an accredited customer? </p></div>
                    <div class="panel faq-panel">
                        <p>Affiliated with local and international forwarders like UPS, FedEx and Air21 to make a partnership that ensures fast, reliable, and economical freight services.</p>
                    </div>
                    <div class="accordion accord-faq"><p>What is LOA?</p></div>
                    <div class="panel faq-panel">
                        <p>We can provide services for disassembly, Packing, Crating of cargo, marine and overland transportation on to factory site installation of equipment and machinery</p>
                    </div>
                    <div class="accordion accord-faq"><p>SPLI 2017 Summer Team Building</p></div>
                    <div class="panel faq-panel">
                        <p>We can provide services for disassembly, Packing, Crating of cargo, marine and overland transportation on to factory site installation of equipment and machinery</p>
                    </div>
                    <div class="accordion accord-faq"><p>SPLI : Certified by ISO 9001:2015</p></div>
                    <div class="panel faq-panel">
                        <p>We can provide services for disassembly, Packing, Crating of cargo, marine and overland transportation on to factory site installation of equipment and machinery</p>
                    </div>
            </div>              
        </div-->
	     <br>
         <div class="footer">
            <div class="col-2 footlink ulast">
                <h3>Services</h3>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="services.php" >Services</a></li>
                    <li><a href="facilities.php">Facilities</a></li>
                    <li><a href="about.php">About</a></li>
                    <li><a href="contact.php">Contact Us</a></li>
                </ul>
                <img src="img/spliLogo.jpg" alt="SPLI Logo">
                 <p>Susumi Philippine Logistics, Inc.</p>
                 <p>SPLI - All Rights Reserved 2018&reg;</p>
            </div>
            <div class="col-2 footlink flast">
                <h3>We are social</h3>
                <a href="https://www.google.com/maps?ll=14.141268,121.132156&z=16&t=m&hl=en-US&gl=PH&mapclient=embed&cid=18143372728270693435" title="Find in Google Map" target="_blank" ><img src="img/001-google.png" alt="SPLI Logo"></a>
                <a href="#"><img src="img/002-skype.png" alt="SPLI Logo"></a>
                <a href="https://plus.google.com/share?url=" title="Share on Google+" target="_blank"><img src="img/003-google-plus.png" alt="SPLI Logo"></a>
                <a  href="https://www.facebook.com/sharer/sharer.php?u=" title="Share on Facebook" target="_blank"><img src="img/004-facebook.png" alt="SPLI Logo"></a>
                <h5>Tel. No.: +63 43 405 7020</h5>
                <h5>Email : inquire@spli.ph</h5>
                <h5>Former SGL Philippines E-Zone Services Inc.</h5>
            </div>
            <div class="col-2 footlink flast">
                <h3>Need Help?</h3>
                <ul>
                    <li><a href="services.php">International Multi-Through Transportation</a></li>
                    <li><a href="services.php" >Ocean &amp; AirCargo Business </a></li>
                    <li><a href="services.php">Currier Service</a></li>
                    <li><a href="services.php">Project Cargo Business</a></li>
                    <li><a href="services.php">Storage and Warehousing</a></li>
                    <li><a href="services.php">Trucking Services</a></li>
                </ul>
            </div>
        </div>
    </div>
    <p class="coder">Website Developed by: N. Valenzuela 2018 - valenzuela.nomer@yahoo.com</p>

    <script src="js/jquery3-3-1.js"></script>
	<script src="js/accord.js"></script>
	<script src="js/js_slide.js"></script> 
</body>
</html>