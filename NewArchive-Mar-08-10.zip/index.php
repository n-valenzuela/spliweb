<!DOCTYPE html>
<html>
    <head>
        <title>Home - SPLI</title>
        <link rel="stylesheet" href="css/main.css" type="text/css" />
    	<link rel="stylesheet" href="css/home.css" type="text/css" />
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="icon" href="http://www.spli.ph/Lobo.ico" type="image/x-icon" />
        <!-- This is needed for IE -->
        <link rel="shortcut icon" href="http://www.spli.ph/Lobo.ico" type="image/ico" />
    </head>
<body>
    <div class="wrap">
        <div class="head sticky">
            <div class="col-2 logo">
                <img src="img/menu-button.png">
                <h2>Susumi Philippine Logistics, Inc.</h2>
            </div>
            <div class="col-4 navs">
                <ul>
                    <li class="inhere"><a href="index.php">Home</a></li>
                    <li class="here"><a href="services.php">Services</a></li>
                    <li class="here"><a href="facilities.php">Facilities</a></li>
                    <li class="here"><a href="about.php">About</a></li>
                    <li class="here"><a href="contact.php">Contact Us</a></li>
                </ul>
            </div>
        </div>
        <div class="banner">
			<div class="slider col-6">
				<div class="slide current">
                    <img src="img/slide4.jpg">
                    <h2>S P L I
                        <br>
                    We are proud to be part of your progress...</h2>
				</div>
				<div class="slide"><img src="img/slide2.jpg">
				    <h2>Run out of Space? <br><br>Keep your items at our warehouse.</h2>
                    <a href="facilities.php">See Our Facility</a>
				</div>
				<div class="slide"><img src="img/slide3.jpg">
				    <h2>Got Import and Export Requirements? <br><br>We can handdle that for you.</h2>
                    <a href="services.php">See Our Services</a>
				</div>
				<div class="slide"><img src="img/slide1.jpg">
				    <h2>Want to know more about SPLI?</h2>
                    <a href="about.php">Know More</a>
				</div>
			</div>
            <p class="prev"><</p>
            <p class="next">></p>
        </div>
        <div class="main1">
            <div class="col-3 who">
                <h2>Our Commitment</h2>
                <p>To give our clients the best support for import and export shipments, goods handling, storage and warehousing solutions, business project solutions and best customer service satisfaction.<br><br>We acquired the term "Susumi", a Japanese term for “Progress” to show customers our main goal in shipping and forwarding industry, which is to be part of their progress in any kind of business. We offer a wide range of services from storage and warehousing, import or export handling to trucking.</p>
                <img src="img/Logo.png">
            </div>
            <div class="col-3 gallery1">
                <img src="img/handshake.png">
                <a href="about.php" class="links">More About SPLI</a>
            </div>
        </div>
        <div class="main2">
            <div class="col-3 gallery2">
                <a class="website" href="https://www.peza.gov.ph/" target="_blank" Tooltip="Philippine Economic Zone Authority"><img src="img/peza.png"></a>
                <a class="website" href="https://www.iso.org/" target="_blank" Tooltip="ISO 9001:2015"><img src="img/ISO_9001-2015.jpg"></a>
                <a class="website" href="https://www.denr.gov.ph/" target="_blank" Tooltip="Dept. of Environment and Natural Resources"><img src="img/DENR.png"></a>
                <a class="website" href="https://pdea.gov.ph/" target="_blank" Tooltip="Philippine Drug Enforcement Authority"><img src="img/PDEA.png"></a>
                <a class="website" href="https://www.dof.gov.ph/index.php/directory/bureau-of-customs/" target="_blank" Tooltip="Bureau of Customs"><img src="img/BOC.jpg"></a>
                <a class="website" href="https://www.cab.gov.ph/" target="_blank" Tooltip="Civil Aeronautics Board"><img src="img/CAB.jpg"></a>
            </div>
            <div class="col-3 why">
            <h2>Our Compliance</h2>
            <p>We always make sure that we are qualified to handle, operate and do business with our clients. We have certificates from the Government and private certifying companies. <br><br> We comply with things you required so you can be confident and feel secured. Because we value your items and your business you can always talk to us about additional requirements to work on together. </p>
            <a href="contact.php" class="links1">Contact Us</a>
            </div>
        </div>
        <div class="partners">
            <h2>Our Partners in Industry</h2>
                <div class="col-2 something">    
                    <img src="img/trucking.png">
                        <h3>Trucking</h3>
                        <p>As a third party logistics, we our own and several trucking partners so you won't run out of truck when you need one and to continue to move your items.</p>
                </div>
                <div class="col-2 something">    
                    <img src="img/affiliates.png">
                        <h3>Affiliates</h3>
                        <p>SPLI is closely affiliated with international courier service like Federal Express (FedEx) and its Philippine sole licensee Airfreight 2100, Inc (Air21). SPLI also utilizes services from international aircraft providers for efficient cargo shipping.</p>
                </div>
                <div class="col-2 something">    
                    <img src="img/slide1.jpg">
                        <h3>Agents</h3>
                        <p>Connecting industry to industry business, internationally or locally is best through SPLI. We don't just stick to work with one shipper we outsource and partner with our agents here and abroad.</p>
                </div>
        </div>
         <div class="footer">
            <div class="col-2 footlink ulast">
                    <h3>Services</h3>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="services.php" >Services</a></li>
                    <li><a href="facilities.php">Facilities</a></li>
                    <li><a href="about.php">About</a></li>
                    <li><a href="contact.php">Contact Us</a></li>
                </ul>
                <img src="img/spliLogo.jpg" alt="SPLI Logo">
                 <p>Susumi Philippine Logistics, Inc.</p>
                 <p>SPLI - All Rights Reserved 2018&reg;</p>
            </div>
            <div class="col-2 footlink flast">
                <h3>We are social</h3>
                <a href="https://www.google.com/maps?ll=14.141268,121.132156&z=16&t=m&hl=en-US&gl=PH&mapclient=embed&cid=18143372728270693435" title="Find in Google Map" target="_blank" ><img src="img/001-google.png" alt="SPLI Logo"></a>
                <a href="#"><img src="img/002-skype.png" alt="SPLI Logo"></a>
                <a href="https://plus.google.com/share?url=" title="Share on Google+" target="_blank"><img src="img/003-google-plus.png" alt="SPLI Logo"></a>
                <a  href="https://www.facebook.com/sharer/sharer.php?u=" title="Share on Facebook" target="_blank"><img src="img/004-facebook.png" alt="SPLI Logo"></a>
                <h5>Tel. No.: +63 43 405 7020</h5>
                <h5>Email : inquire@spli.ph</h5>
                <h5>Former SGL Philippines E-Zone Services Inc.</h5>
            </div>
            <div class="col-2 footlink flast">
                <h3>Need Help?</h3>
                <ul>
                    <li><a href="services.php">International Multi-Through Transportation</a></li>
                    <li><a href="services.php" >Ocean &amp; AirCargo Business </a></li>
                    <li><a href="services.php">Currier Service</a></li>
                    <li><a href="services.php">Project Cargo Business</a></li>
                    <li><a href="services.php">Storage and Warehousing</a></li>
                    <li><a href="services.php">Trucking Services</a></li>
                </ul>
            </div>
        </div>
    </div>
        <p class="coder">Website Developed by: N. Valenzuela 2018 - valenzuela.nomer@yahoo.com</p>

    <script src="js/jquery3-3-1.js" type="text/javascript"></script>
    <script src="js/js_slide.js" type="text/javascript"></script>
    <script src="js/accord.js" type="text/javascript"></script>
</body>
    
</html>
