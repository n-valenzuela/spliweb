
$(document).ready(function(){
	
	window.onscroll = function() {fixedNav()};

	var navbar = $(".heads");
	var sticky = navbar.offsetTop;
	var bgNav = $(".logo, .navs");

	function fixedNav() {
	  if (window.pageYOffset >= sticky) {
	    navbar.addClass("sticky");
	  }
	  else if(window.pageYOffset <= 0){
	  	bgNav.css('background-color', 'rgb(134, 0, 179)');
	  	  }
	   else {
	    navbar.removeClass("sticky");
	    bgNav.css('background-color', 'rgb(255, 140, 26)');
	  }
	}
	var currentIndex = 0;
  	items = $('.slider div');
  	itemAmt = items.length;

	function cycleItems() {
  		var item = $('.slider div').eq(currentIndex);
  		items.hide();
  		item.css('display','inline-block');
	}

	var autoSlide = setInterval(function() {
	 	currentIndex += 1;
	  	if (currentIndex > itemAmt -1) {
	    currentIndex = 0;
	  }
	  cycleItems();
	}, 10000);

	//next and previous p tag
	$('.next').click(function(){
		var currentSli = $('.current')
		var nextSli = currentSli.next();
		
		currentSli.fadeOut(300).removeClass('current');
		nextSli.fadeIn(300).addClass('current');
		
		if(nextSli.length ==0){
		  $('.slide').first().fadeIn(300).addClass('current');
		}
	}); 

	$('.prev').click(function(){
		var currentSli = $('.current')
		var prevSli = currentSli.prev();
		
		currentSli.fadeOut(300).removeClass('current');
		prevSli.fadeIn(300).addClass('current');
		
		if(prevSli.length ==0 ){
		  $('.slide').last().fadeIn(300).addClass('current');
		}
	}); 


	$('.tab ul a').on('click', function(e){
		var currentTab = $(this).attr('href');
		$('.tab-con' + currentTab).show().siblings().hide();

		$(this).parent('li').addClass('act').siblings().removeClass('act');
		e.preventDefault();
	});

	$('.website').hover(function(event){
		var toolTip = $(this).attr('Tooltip');
		$('<span class="tooltip"></span>').text(toolTip)
		.appendTo('body')
		.css('top', (event.pageY -30)+ 'px')
		.css('left', (event.pageX  -0)+'px')
		.fadeIn('slow');
	}, function(){
		$('.tooltip').remove();
	});

});
