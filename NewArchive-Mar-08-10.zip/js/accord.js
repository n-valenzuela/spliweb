$(document).ready(function(){
	var accord = $('.accordion');

	for (var i = 0; i < accord.length; i++) {
		accord[i].addEventListener('click', function(){
			this.classList.toggle('activeaccord');
			var panel = this.nextElementSibling;
			if (panel.style.display ==='block') {
				panel.style.display = 'none';
			}else{
				panel.style.display = 'block';
			}
		});
	}
	$('.lightbox').click(function(){
		$('.backdrop, .box').animate({'opacity':'.50'}, 300, 'linear');
		$('.box').animate({'opacity':'1.00'}, 300, 'linear');
		$('.backdrop, .box').css('display', 'block',
			'position', 'fixed');
		document.getElementById("imgset").src = this.src;
	});
		
	$('.close').click(function(){
		close_box();
	});
	$('.backdrop').click(function(){
		close_box();
	})

	function close_box(){
		$('.backdrop, .box').animate({'opacity': '0'}, 300, 'linear', function(){
			$('.backdrop, .box').css('display', 'none');
		})
	}

	$('.logo img').click(function(){
		$('.navs').toggleClass('navs1');	
                $('.here, .inhere').toggleClass('navs2');
                $('.here').css('display', 'inline-block',
                                      'width', '100%', 
                                       'float', 'left');
                $('.inhere').addClass('navs3, navs2');
		
});	

});
