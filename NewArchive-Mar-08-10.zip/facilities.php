<!DOCTYPE html>
<html>
    <head>
        <title>SPLI - Facilities</title>
        <link rel="stylesheet" href="css/main.css" type="text/css"/>
    	<link rel="stylesheet" href="css/facilities.css" type="text/css"/>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="icon" href="http://www.spli.ph/Lobo.ico" type="image/x-icon" />
    <!-- This is needed for IE -->
    <link rel="shortcut icon" href="http://www.spli.ph/Lobo.ico" type="image/ico" />
    </head>
<body>
    <div class="wrap">
        <div class="head sticky">
            <div class="col-2 logo">
                <img src="img/menu-button.png">
                <h2>Susumi Philippine Logistics, Inc.</h2>
            </div>
            <div class="col-4 navs">
                <ul>
                    <li class="here"><a href="index.php" >Home</a></li>
                    <li class="here"><a href="services.php" >Services</a></li>
                    <li class="inhere"><a href="facilities.php">Facilities</a></li>
                    <li class="here"><a href="about.php">About</a></li>
                    <li class="here"><a href="contact.php">Contact Us</a></li>
                </ul>
            </div>
        </div>
       <div class="wehave">
            <div class="intro col-6">
                <h3>Warehouse Building</h3>
                <p>Located both on First Philippine Industrial Park, SPLI has two (2) warehouses. Building H1&amp;H2. where our main office and warehouse is located and Building M. as our extended and larger warehouse. We placed our business closer to over hundreds of manufacturing companies in Batangas and Laguna so we can support their business and ours.</p>
            </div>
            <br>
            <div class="bldg">
                <div class="col-3 whse">
                   <img src="img/h1h2.jpg">
                   <h3>Building H1&amp;H2</h3>
                   <h4>Address:</h4>
                   <p>Lot 4E, Building H1 and H2, Special Economic Zone, First Philippine Industrial Park, Brgy. Sta. Anastacia, Sto. Tomas, Batangas 4234</p>
                   <p> -  <strong> Capacity : </strong>  2,680 sqm.</p>
                   <p> -  <strong> Rack Storage : </strong> Yes</p>
                   <p> -  <strong> Control Temperature Storage : </strong> Yes</p>
                   <p> -  <strong> Dangerous Goods Storage : </strong> Yes</p>
                   <p> -  <strong> Raw Materials : </strong>Yes</p>
                   <p> -  <strong> General Cargo : </strong>Yes</p>
                </div>
                <div class="col-3 whse">
                   <img src="img/BM1.jpg">
                   <h3>Building M</h3>
                   <h4>Address:</h4>
                   <p>Lot 30-B, Phase 1B, First Philippine Industrial Park, Brgy. Ulango, Tanauan City, Batangas 4232 </p>
                   <p> -  <strong> Capacity : </strong>3,480 sqm.</p>
                   <p> -  <strong> Rack Storage : </strong>Yes</p>
                   <p> -  <strong> Control Temperature Storage : </strong>No</p>
                   <p> -  <strong> Dangerous Goods Storage : </strong>No</p>
                   <p> -  <strong> Raw Materials : </strong>Yes</p>
                   <p> -  <strong> General Cargo : </strong>Yes</p>
                </div>
            </div>
       </div>
              <div class="img-selection">
            <h2><em>SPLI at a glance</em></h2>
              <div class="col-6 sets">
                    <div class="img-set">
                          <img src="img/b1.jpg" class="lightbox" id="image01" alt="New Forklift and Reach Truck">
                          <p>New Forklift and Reach Truck</p>
                    </div>
                    <div class="img-set">
                          <img src="img/b2.jpg" class="lightbox image" alt="Inside Bldg M.">
                          <p>Inside Bldg M.</p>
                    </div>
                    <div class="img-set">
                          <img src="img/b3.jpg" class="lightbox image" alt="Controlled Temp. Room" >
                          <p>Controlled Temp. Room</p>
                    </div>
                    <div class="img-set">
                          <img src="img/b4.jpg" class="lightbox" alt="Main Building's Rack Storage." >
                          <p>Main Building's Rack Storage.</p>
                    </div>
                    <div class="img-set">
                          <img src="img/B5.jpg" class="lightbox" alt="Double Stack Pallet." >
                          <p>Double Stack Pallet.</p>
                    </div>
                    <div class="img-set">
                          <img src="img/B6.jpg" class="lightbox" alt="Paper Roll Cargoes" >
                          <p>Paper Roll Cargoes</p>
                    </div>
                    <div class="img-set">
                          <img src="img/b7.jpg" class="lightbox" alt="Mezzane view at Bldg M.">
                          <p>Mezzane view at Bldg M.</p>
                    </div>
                    <div class="img-set">
                          <img src="img/b8.jpg" class="lightbox" alt="Warehouse Security">
                          <p>Warehouse Security</p>
                    </div>
                    <div class="img-set">
                          <img src="img/b9.jpg" class="lightbox" alt="Inside Main Building Warehouse">
                          <p>Inside Main Building Warehouse</p>
                    </div>
                    <div class="img-set">
                          <img src="img/B10.jpg" class="lightbox" alt="New Rack Storage in Building M">
                          <p>New Rack Storage in Building M</p>
                    </div>
                        <div class="backdrop"></div>
                          <div class="box">
                           <div class="close">
                              <h2>x</h2>
                          </div>
                          <h5>SPLI Gallery</h5>
                          <img id="imgset">
                      </div>
            </div>
        </div>
        <div class="footer">
            <div class="col-2 footlink ulast">
                <h3>Services</h3>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="services.php" >Services</a></li>
                    <li><a href="facilities.php">Facilities</a></li>
                    <li><a href="about.php">About</a></li>
                    <li><a href="">Contact Us</a></li>
                </ul>
                <img src="img/spliLogo.jpg" alt="SPLI Logo">
                 <p>Susumi Philippine Logistics, Inc.</p>
                 <p>SPLI - All Rights Reserved 2018&reg;</p>
            </div>
            <div class="col-2 footlink flast">
                <h3>We are social</h3>
                <a href="https://www.google.com/maps?ll=14.141268,121.132156&z=16&t=m&hl=en-US&gl=PH&mapclient=embed&cid=18143372728270693435" title="Find in Google Map" target="_blank" ><img src="img/001-google.png" alt="SPLI Logo"></a>
                <a href="#"><img src="img/002-skype.png" alt="SPLI Logo"></a>
                <a href="https://plus.google.com/share?url=" title="Share on Google+" target="_blank"><img src="img/003-google-plus.png" alt="SPLI Logo"></a>
                <a  href="https://www.facebook.com/sharer/sharer.php?u=" title="Share on Facebook" target="_blank"><img src="img/004-facebook.png" alt="SPLI Logo"></a>
                <h5>Tel. No.: +63 43 405 7020</h5>
                <h5>Email : inquire@spli.ph</h5>
                <h5>Former SGL Philippines E-Zone Services Inc.</h5>
            </div>
            <div class="col-2 footlink flast">
                <h3>Need Help?</h3>
                <ul>
                    <li><a href="services.php">International Multi-Through Transportation</a></li>
                    <li><a href="services.php" >Ocean &amp; AirCargo Business </a></li>
                    <li><a href="services.php">Currier Service</a></li>
                    <li><a href="services.php">Project Cargo Business</a></li>
                    <li><a href="services.php">Storage and Warehousing</a></li>
                    <li><a href="services.php">Trucking Services</a></li>
                </ul>
            </div>
        </div>
      </div>
        <p class="coder">Website Developed by: N. Valenzuela 2018 - valenzuela.nomer@yahoo.com</p>
    <script src="js/jquery3-3-1.js" type="text/javascript"></script>
    <script src="js/js_slide.js" type="text/javascript"></script>
    <script src="js/accord.js" type="text/javascript"></script>
</body>
    
</html>